import { useState } from 'react';
import { Link } from 'react-router';
import { TrendingUp, Users, CheckCircle, AlertTriangle, BarChart2, Activity, Clock, ArrowUpRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';

const weeklyData = [
  { day: 'Mon', failures: 42, fixed: 38 },
  { day: 'Tue', failures: 67, fixed: 61 },
  { day: 'Wed', failures: 55, fixed: 50 },
  { day: 'Thu', failures: 83, fixed: 75 },
  { day: 'Fri', failures: 91, fixed: 84 },
  { day: 'Sat', failures: 34, fixed: 31 },
  { day: 'Sun', failures: 28, fixed: 26 },
];

const trendData = [
  { month: 'Jul', cts: 120, timing: 89, routing: 143 },
  { month: 'Aug', cts: 98, timing: 112, routing: 167 },
  { month: 'Sep', cts: 145, timing: 134, routing: 189 },
  { month: 'Oct', cts: 134, timing: 156, routing: 201 },
  { month: 'Nov', cts: 167, timing: 143, routing: 178 },
  { month: 'Dec', cts: 189, timing: 178, routing: 234 },
];

const topFailures = [
  { id: 'CTS-0008', name: 'No Clock Defined', count: 2847, change: +12, successRate: 96 },
  { id: 'TIM-0023', name: 'Hold Violation', count: 1923, change: +8, successRate: 88 },
  { id: 'DRC-0015', name: 'Antenna Violation', count: 1678, change: -3, successRate: 93 },
  { id: 'PLA-0033', name: 'Placement Density', count: 1456, change: +5, successRate: 84 },
  { id: 'ROU-0041', name: 'Routing Congestion', count: 1204, change: +19, successRate: 79 },
];

const insights = [
  { author: 'Atlas Intelligence', time: '2h ago', body: 'CTS failures increased 12% this week, primarily in Sky130 designs. Most are related to missing create_clock constraints in newly synthesized RTL.', type: 'atlas' },
  { author: 'Community Pattern', time: '5h ago', body: 'Hold violations in GF180 designs are clustering around the 0.15–0.25ns slack range, suggesting a common setup issue with the PDK timing models.', type: 'community' },
  { author: 'Atlas Intelligence', time: '1d ago', body: 'Routing congestion in metal3 is becoming more common in designs targeting >100MHz in Sky130. Atlas recommends lowering placement density target to 70%.', type: 'atlas' },
  { author: 'Community Pattern', time: '2d ago', body: 'LVS floating gate errors in Sky130 PMOS devices reduced by 23% after a documentation update clarifying substrate contact requirements.', type: 'community' },
];

export function CommunityIntelligence() {
  const [timeRange, setTimeRange] = useState('7d');

  return (
    <div style={{ background: 'var(--canvas-bone)', minHeight: '100vh', fontFamily: 'var(--font-ui)' }}>
      {/* Header */}
      <div style={{ background: 'var(--abyss-ink)' }}>
        <div className="max-w-6xl mx-auto px-6 lg:px-8 pt-12 pb-10">
          <p className="text-xs font-semibold tracking-widest uppercase mb-3" style={{ color: 'var(--meridian-gold)' }}>Community Intelligence</p>
          <h1 className="mb-3" style={{ fontFamily: 'var(--font-display)', fontSize: '2.5rem', fontWeight: 700, color: '#FFFFFF' }}>
            Collective Knowledge.
          </h1>
          <p style={{ color: 'rgba(243,242,237,0.6)', maxWidth: '40rem' }}>
            Anonymized, aggregated insights from the TapeItOut engineering community. No proprietary data is ever exposed.
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-10">
        {/* Key Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Active Engineers', value: '3,421', icon: Users, color: '#3B82F6', change: '+124 this week' },
            { label: 'Failures Diagnosed', value: '47,293', icon: Activity, color: 'var(--meridian-gold)', change: '+847 this week' },
            { label: 'Community Fixes', value: '8,934', icon: CheckCircle, color: '#10B981', change: '+203 this week' },
            { label: 'Avg Resolution', value: '4.2h', icon: Clock, color: '#8B5CF6', change: 'Down from 6.1h' },
          ].map(stat => (
            <div key={stat.label} className="rounded-xl border p-5" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
              <div className="flex items-center justify-between mb-3">
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                <span className="text-xs" style={{ color: '#10B981' }}>{stat.change}</span>
              </div>
              <div className="mb-1" style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', fontWeight: 700, color: 'var(--abyss-ink)' }}>
                {stat.value}
              </div>
              <p className="text-xs" style={{ color: '#94A3B8' }}>{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-8">
            {/* Weekly Chart */}
            <div className="rounded-xl border p-6" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
              <div className="flex items-center justify-between mb-6">
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 600, color: 'var(--abyss-ink)' }}>
                  Failures vs. Fixes — This Week
                </h2>
                <div className="flex gap-2">
                  {['7d', '30d', '90d'].map(r => (
                    <button
                      key={r}
                      onClick={() => setTimeRange(r)}
                      className="px-2.5 py-1 rounded text-xs transition-all"
                      style={{
                        background: timeRange === r ? 'var(--abyss-ink)' : 'var(--canvas-bone)',
                        color: timeRange === r ? 'var(--canvas-bone)' : '#64748B',
                        border: '1px solid var(--stone-ridge)',
                      }}
                    >
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={weeklyData} barGap={4}>
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#94A3B8', fontFamily: 'Work Sans' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8', fontFamily: 'Work Sans' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontFamily: 'Work Sans', fontSize: 12, border: '1px solid #E5E7EB', borderRadius: 8 }} />
                  <Bar dataKey="failures" fill="rgba(194,65,12,0.7)" radius={[3, 3, 0, 0]} name="Failures" />
                  <Bar dataKey="fixed" fill="rgba(16,185,129,0.7)" radius={[3, 3, 0, 0]} name="Fixed" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Trend Chart */}
            <div className="rounded-xl border p-6" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
              <h2 className="mb-6" style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 600, color: 'var(--abyss-ink)' }}>
                Failure Category Trends — 6 Months
              </h2>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94A3B8', fontFamily: 'Work Sans' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8', fontFamily: 'Work Sans' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontFamily: 'Work Sans', fontSize: 12, border: '1px solid #E5E7EB', borderRadius: 8 }} />
                  <Line type="monotone" dataKey="cts" stroke="#EC4899" strokeWidth={2} dot={false} name="CTS" />
                  <Line type="monotone" dataKey="timing" stroke="#3B82F6" strokeWidth={2} dot={false} name="Timing" />
                  <Line type="monotone" dataKey="routing" stroke="#10B981" strokeWidth={2} dot={false} name="Routing" />
                </LineChart>
              </ResponsiveContainer>
              <div className="flex items-center gap-4 mt-3">
                {[{ label: 'CTS', color: '#EC4899' }, { label: 'Timing', color: '#3B82F6' }, { label: 'Routing', color: '#10B981' }].map(l => (
                  <div key={l.label} className="flex items-center gap-1.5 text-xs" style={{ color: '#64748B' }}>
                    <div className="w-4 h-0.5 rounded" style={{ background: l.color }} />
                    {l.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Community Insights Feed */}
            <div className="rounded-xl border overflow-hidden" style={{ border: '1px solid var(--stone-ridge)' }}>
              <div className="px-5 py-4 border-b" style={{ background: '#FFFFFF', borderColor: 'var(--stone-ridge)' }}>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.125rem', fontWeight: 600, color: 'var(--abyss-ink)' }}>
                  Intelligence Feed
                </h2>
              </div>
              <div className="divide-y" style={{ background: '#FAFAF7' }}>
                {insights.map((insight, i) => (
                  <div key={i} className="p-5">
                    <div className="flex items-center gap-2 mb-2">
                      <div
                        className="w-6 h-6 rounded flex items-center justify-center text-xs font-bold"
                        style={{
                          background: insight.type === 'atlas' ? 'var(--abyss-ink)' : 'var(--secondary)',
                          color: insight.type === 'atlas' ? 'var(--meridian-gold)' : '#64748B',
                          fontFamily: 'var(--font-mono)',
                        }}
                      >
                        {insight.type === 'atlas' ? 'A' : '◎'}
                      </div>
                      <span className="text-xs font-semibold" style={{ color: 'var(--abyss-ink)' }}>{insight.author}</span>
                      <span className="text-xs" style={{ color: '#94A3B8' }}>{insight.time}</span>
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: '#475569', fontFamily: 'var(--font-editorial)' }}>{insight.body}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Top Failures */}
            <div className="rounded-xl border overflow-hidden" style={{ border: '1px solid var(--stone-ridge)' }}>
              <div className="px-4 py-3 border-b" style={{ background: 'var(--abyss-ink)', borderColor: 'rgba(255,255,255,0.08)' }}>
                <h4 className="text-sm font-semibold text-white">Most Common Failures</h4>
              </div>
              <div className="divide-y" style={{ background: '#FAFAF7' }}>
                {topFailures.map((f, i) => (
                  <Link key={f.id} to={`/atlas/error/${f.id.toLowerCase()}`} className="flex items-center gap-3 px-4 py-3 hover:bg-white transition-colors group">
                    <span className="text-xs font-bold w-4 text-center" style={{ color: '#94A3B8' }}>{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold group-hover:underline" style={{ color: 'var(--abyss-ink)' }}>{f.name}</span>
                        <span className={`text-xs font-medium ${f.change > 0 ? 'text-red-500' : 'text-green-500'}`}>
                          {f.change > 0 ? '↑' : '↓'}{Math.abs(f.change)}%
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs" style={{ color: '#94A3B8', fontFamily: 'var(--font-mono)' }}>{f.id}</span>
                        <span className="text-xs" style={{ color: '#94A3B8' }}>·</span>
                        <span className="text-xs" style={{ color: '#10B981' }}>{f.successRate}% fix rate</span>
                      </div>
                    </div>
                    <span className="text-xs font-medium" style={{ color: '#475569', fontFamily: 'var(--font-mono)' }}>
                      {f.count.toLocaleString()}
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Popular Fixes */}
            <div className="rounded-xl border p-5" style={{ border: '1px solid var(--stone-ridge)', background: '#FFFFFF' }}>
              <h4 className="text-xs font-semibold tracking-widest uppercase mb-4" style={{ color: '#94A3B8' }}>Popular Fixes This Week</h4>
              <div className="space-y-3">
                {[
                  { fix: 'Add create_clock to SDC', count: 847, pct: 96 },
                  { fix: 'Reduce placement density to 70%', count: 623, pct: 84 },
                  { fix: 'Add substrate contacts (LVS)', count: 445, pct: 91 },
                  { fix: 'Enable hold repair in CTS', count: 389, pct: 88 },
                ].map((f, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-1">
                      <span style={{ color: '#475569' }}>{f.fix}</span>
                      <span style={{ color: '#10B981' }}>{f.pct}%</span>
                    </div>
                    <div className="h-1 rounded-full" style={{ background: 'var(--secondary)' }}>
                      <div className="h-1 rounded-full" style={{ width: `${f.pct}%`, background: '#10B981' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Privacy Note */}
            <div className="rounded-xl border p-4" style={{ border: '1px solid rgba(212,175,55,0.2)', background: 'rgba(212,175,55,0.04)' }}>
              <p className="text-xs leading-relaxed" style={{ color: '#64748B' }}>
                <span className="font-semibold" style={{ color: 'var(--meridian-gold)' }}>Privacy First.</span> All community data is anonymized and aggregated. No design IP, netlists, or proprietary information is ever stored or exposed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
