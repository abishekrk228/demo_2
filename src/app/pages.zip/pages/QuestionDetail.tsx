import { useState } from 'react';
import { Link, useParams } from 'react-router';
import { CheckCircle, ThumbsUp, MessageSquare, Share2, Bookmark, ArrowRight, Users, Eye, Clock } from 'lucide-react';
import { ConfidenceMeter } from '../components/ConfidenceMeter';
import { StatusBadge } from '../components/StatusBadge';
import { CodeViewer } from '../components/CodeViewer';

const question = {
  title: 'OpenROAD CTS failure: "No clock defined in design" after floorplanning',
  tags: ['CTS', 'OpenROAD', 'Sky130', 'Clock', 'SDC'],
  views: 2847,
  author: 'V. Krishnamurthy',
  date: 'Dec 14, 2024',
  body: `I'm running the OpenROAD flow on a RISC-V core targeting Sky130. After floorplanning completes successfully, the CTS stage fails with:

[ERROR CTS-0008] No clock defined in design.

I've verified that synthesis completes without errors. The netlist looks correct. This happens consistently at the CTS stage. My SDC file is attached below.`,
  sdc: `# constraints.sdc
set_units -time ns -resistance kOhm -capacitance pF -voltage V -current mA
set_max_fanout 20 [current_design]

# PROBLEM: Missing create_clock constraint!
# No clock source defined here

set_input_delay 0.5 -clock clk [all_inputs]
set_output_delay 0.5 -clock clk [all_outputs]
set_max_transition 0.25 [current_design]`,
};

const atlasAnalysis = {
  failure: 'CTS-0008: No clock defined in design',
  confidence: 94,
  rootCause: 'The SDC constraints file is missing a create_clock or create_generated_clock directive. Without an explicit clock definition, OpenROAD\'s CTS engine has no clock tree to build.',
  recommendation: 'Add a create_clock constraint to your SDC file before the CTS stage. The clock source net name must match the actual clock port in your netlist.',
  evidence: [
    'SDC file contains set_input_delay referencing "clk" but no create_clock defining it',
    'Error code CTS-0008 is exclusively triggered by missing clock definitions (seen 2,847 times)',
    'Synthesis log shows no SDC parsing errors — constraint file was read but clock was silently undefined',
  ],
  impact: 'CTS cannot proceed without a defined clock. No downstream timing analysis is possible.',
  seenCount: 2847,
  successRate: 96,
};

const fixCode = `# constraints.sdc — Fixed Version
set_units -time ns -resistance kOhm -capacitance pF -voltage V -current mA
set_max_fanout 20 [current_design]

# SOLUTION: Add create_clock constraint
# Replace 'clk' with your actual clock port name
# Replace 10.0 with your target clock period in nanoseconds
create_clock -name clk -period 10.0 [get_ports clk]

# Optional: define clock uncertainty
set_clock_uncertainty 0.1 [get_clocks clk]
set_clock_transition 0.15 [get_clocks clk]

set_input_delay 0.5 -clock clk [all_inputs]
set_output_delay 0.5 -clock clk [all_outputs]
set_max_transition 0.25 [current_design]`;

const discussion = [
  { author: 'M. Patel', time: '3h ago', body: 'Had this exact issue last week. The create_clock fix works. Make sure the port name in get_ports matches exactly — Sky130 is case-sensitive.', votes: 12 },
  { author: 'T. Nakamura', time: '5h ago', body: 'Also worth checking: if you have multiple clocks, you\'ll need a create_clock for each one, plus create_generated_clock for any divided/multiplied clocks.', votes: 8 },
  { author: 'A. Rodriguez', time: '8h ago', body: 'The 10ns period (100MHz) is a safe starting point for Sky130. If you\'re pushing higher frequency, start with a relaxed constraint and tighten iteratively.', votes: 5 },
];

export function QuestionDetail() {
  const { slug } = useParams();
  const [activeTab, setActiveTab] = useState<'explanation' | 'discussion'>('explanation');

  return (
    <div style={{ background: 'var(--canvas-bone)', minHeight: '100vh', fontFamily: 'var(--font-ui)' }}>
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Content */}
          <main className="lg:col-span-8">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs mb-6" style={{ color: '#94A3B8' }}>
              <Link to="/" style={{ color: '#94A3B8' }}>Home</Link>
              <span>/</span>
              <Link to="/errors?category=cts" style={{ color: '#94A3B8' }}>CTS</Link>
              <span>/</span>
              <span style={{ color: '#475569' }}>CTS-0008</span>
            </div>

            {/* Question Header */}
            <div className="mb-8">
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <StatusBadge status="fixed" />
                <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ background: 'rgba(194,65,12,0.08)', color: 'var(--topography-rust)', border: '1px solid rgba(194,65,12,0.15)' }}>Critical</span>
                {question.tags.map(tag => (
                  <span key={tag} className="px-2 py-0.5 rounded text-xs" style={{ background: 'var(--secondary)', color: '#475569' }}>{tag}</span>
                ))}
              </div>

              <h1 className="mb-4 leading-tight" style={{ fontFamily: 'var(--font-display)', fontSize: '1.75rem', fontWeight: 700, color: 'var(--abyss-ink)' }}>
                {question.title}
              </h1>

              <div className="flex flex-wrap items-center gap-4 text-xs" style={{ color: '#94A3B8' }}>
                <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{question.views.toLocaleString()} views</span>
                <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />Asked by {question.author}</span>
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{question.date}</span>
                <button className="flex items-center gap-1 hover:text-current transition-colors"><Share2 className="w-3.5 h-3.5" />Share</button>
                <button className="flex items-center gap-1 hover:text-current transition-colors"><Bookmark className="w-3.5 h-3.5" />Save</button>
              </div>
            </div>

            {/* Atlas Summary Card */}
            <div className="rounded-xl overflow-hidden border mb-8" style={{ border: '1px solid var(--stone-ridge)' }}>
              <div className="px-5 py-4 flex items-center justify-between border-b" style={{ background: 'var(--abyss-ink)', borderColor: 'rgba(255,255,255,0.08)' }}>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded flex items-center justify-center" style={{ background: 'var(--meridian-gold)' }}>
                    <span style={{ fontSize: '0.6rem', fontWeight: 700, color: 'var(--abyss-ink)', fontFamily: 'var(--font-mono)' }}>A</span>
                  </div>
                  <span className="text-sm font-semibold text-white">Atlas Diagnosis</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs" style={{ color: 'rgba(243,242,237,0.5)' }}>Seen {atlasAnalysis.seenCount.toLocaleString()} times</span>
                  <StatusBadge status="fixed" />
                </div>
              </div>

              <div className="p-5 space-y-5" style={{ background: '#FAFAF7' }}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <p className="text-xs font-medium mb-2" style={{ color: '#94A3B8' }}>Failure</p>
                    <p className="text-sm font-medium" style={{ color: 'var(--topography-rust)', fontFamily: 'var(--font-mono)' }}>{atlasAnalysis.failure}</p>
                  </div>
                  <div>
                    <ConfidenceMeter score={atlasAnalysis.confidence} />
                  </div>
                </div>

                <div className="h-px" style={{ background: 'var(--stone-ridge)' }} />

                <div>
                  <p className="text-xs font-medium mb-2" style={{ color: '#94A3B8' }}>Root Cause</p>
                  <p className="text-sm leading-relaxed" style={{ color: '#374151' }}>{atlasAnalysis.rootCause}</p>
                </div>

                <div className="rounded-lg p-4" style={{ background: 'rgba(212,175,55,0.08)', border: '1px solid rgba(212,175,55,0.2)' }}>
                  <p className="text-xs font-semibold mb-2" style={{ color: 'var(--meridian-gold)' }}>RECOMMENDED FIX</p>
                  <p className="text-sm" style={{ color: '#374151' }}>{atlasAnalysis.recommendation}</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg p-3 text-center" style={{ background: 'rgba(16,185,129,0.06)', border: '1px solid rgba(16,185,129,0.15)' }}>
                    <div className="text-xl font-bold mb-0.5" style={{ color: '#10B981', fontFamily: 'var(--font-display)' }}>{atlasAnalysis.successRate}%</div>
                    <p className="text-xs" style={{ color: '#64748B' }}>Community Success Rate</p>
                  </div>
                  <div className="rounded-lg p-3 text-center" style={{ background: 'rgba(15,23,42,0.04)', border: '1px solid var(--stone-ridge)' }}>
                    <div className="text-xl font-bold mb-0.5" style={{ color: 'var(--abyss-ink)', fontFamily: 'var(--font-display)' }}>{atlasAnalysis.seenCount.toLocaleString()}</div>
                    <p className="text-xs" style={{ color: '#64748B' }}>Times Diagnosed</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex border-b mb-6" style={{ borderColor: 'var(--stone-ridge)' }}>
              {(['explanation', 'discussion'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className="px-4 py-2.5 text-sm font-medium capitalize transition-colors border-b-2 -mb-px"
                  style={{
                    borderColor: activeTab === tab ? 'var(--abyss-ink)' : 'transparent',
                    color: activeTab === tab ? 'var(--abyss-ink)' : '#94A3B8',
                  }}
                >
                  {tab} {tab === 'discussion' && `(${discussion.length})`}
                </button>
              ))}
            </div>

            {activeTab === 'explanation' && (
              <div className="space-y-8">
                {/* Question Body */}
                <div className="rounded-xl border p-6" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
                  <h3 className="text-sm font-semibold mb-3" style={{ color: '#94A3B8' }}>ORIGINAL QUESTION</h3>
                  <div className="prose text-sm leading-relaxed mb-4" style={{ color: '#374151' }}>
                    <p style={{ whiteSpace: 'pre-wrap' }}>{question.body}</p>
                  </div>
                  <CodeViewer code={question.sdc} language="sdc" title="constraints.sdc" highlightLines={[2, 3]} />
                </div>

                {/* Evidence */}
                <div className="rounded-xl border p-6" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
                  <h3 className="text-sm font-semibold mb-4" style={{ color: '#94A3B8', letterSpacing: '0.08em' }}>ATLAS EVIDENCE</h3>
                  <ul className="space-y-3">
                    {atlasAnalysis.evidence.map((e, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm" style={{ color: '#374151' }}>
                        <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#10B981' }} />
                        {e}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Accepted Answer */}
                <div className="rounded-xl overflow-hidden border" style={{ border: '2px solid var(--meridian-gold)' }}>
                  <div className="px-5 py-3 flex items-center justify-between" style={{ background: 'rgba(212,175,55,0.06)' }}>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" style={{ color: 'var(--meridian-gold)' }} />
                      <span className="text-sm font-semibold" style={{ color: 'var(--meridian-gold)' }}>Accepted Solution</span>
                    </div>
                    <span className="text-xs" style={{ color: '#94A3B8' }}>96% success rate · {atlasAnalysis.seenCount.toLocaleString()} confirmations</span>
                  </div>
                  <div className="p-6" style={{ background: '#FFFFFF' }}>
                    <p className="text-sm leading-relaxed mb-5" style={{ fontFamily: 'var(--font-editorial)', color: '#374151', fontSize: '0.9375rem' }}>
                      Add a <code style={{ fontFamily: 'var(--font-mono)', background: 'rgba(0,0,0,0.06)', padding: '0.1em 0.4em', borderRadius: '0.25rem' }}>create_clock</code> directive to your SDC file. The constraint must reference the actual clock input port name in your synthesized netlist. For Sky130, verify the port exists using OpenROAD's <code style={{ fontFamily: 'var(--font-mono)', background: 'rgba(0,0,0,0.06)', padding: '0.1em 0.4em', borderRadius: '0.25rem' }}>get_ports</code> command.
                    </p>
                    <CodeViewer code={fixCode} language="sdc" title="constraints.sdc (Fixed)" highlightLines={[4, 5, 6, 7]} />
                    <div className="mt-4 flex items-center gap-4">
                      <button className="flex items-center gap-1.5 text-sm" style={{ color: '#64748B' }}>
                        <ThumbsUp className="w-4 h-4" /> Helpful (147)
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'discussion' && (
              <div className="space-y-4">
                {discussion.map((d, i) => (
                  <div key={i} className="rounded-xl border p-5" style={{ background: '#FFFFFF', border: '1px solid var(--stone-ridge)' }}>
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--secondary)' }}>
                        <span className="text-xs font-semibold" style={{ color: 'var(--abyss-ink)' }}>{d.author[0]}</span>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm font-medium" style={{ color: 'var(--abyss-ink)' }}>{d.author}</span>
                          <span className="text-xs" style={{ color: '#94A3B8' }}>{d.time}</span>
                        </div>
                        <p className="text-sm leading-relaxed" style={{ color: '#475569' }}>{d.body}</p>
                        <button className="flex items-center gap-1 mt-3 text-xs" style={{ color: '#94A3B8' }}>
                          <ThumbsUp className="w-3.5 h-3.5" /> {d.votes}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>

          {/* Right Sidebar */}
          <aside className="lg:col-span-4">
            <div className="sticky top-24 space-y-5">
              {/* Run Atlas CTA */}
              <div className="rounded-xl border p-5 text-center" style={{ background: 'var(--abyss-ink)', border: '1px solid var(--abyss-ink)' }}>
                <div className="w-10 h-10 rounded-lg mx-auto mb-3 flex items-center justify-center" style={{ background: 'var(--meridian-gold)' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: 'var(--abyss-ink)' }}>A</span>
                </div>
                <h4 className="font-semibold text-white mb-2">Have a similar issue?</h4>
                <p className="text-xs mb-4" style={{ color: 'rgba(243,242,237,0.6)' }}>Run Atlas analysis on your specific logs and constraints.</p>
                <Link to="/atlas" className="block w-full py-2.5 rounded-lg text-sm font-semibold transition-all" style={{ background: 'var(--meridian-gold)', color: 'var(--abyss-ink)' }}>
                  Run Atlas Analysis
                </Link>
              </div>

              {/* Related Questions */}
              <div className="rounded-xl border p-5" style={{ border: '1px solid var(--stone-ridge)', background: '#FFFFFF' }}>
                <h4 className="text-xs font-semibold tracking-widest uppercase mb-4" style={{ color: '#94A3B8' }}>Related Questions</h4>
                <div className="space-y-3">
                  {[
                    'CTS fails with "clock not found" in Innovus',
                    'Missing clock in synthesis output',
                    'Generated clock not recognized by CTS',
                    'Multiple clock domains in OpenROAD',
                  ].map(q => (
                    <Link key={q} to="#" className="flex items-start gap-2 group text-xs" style={{ color: '#475569' }}>
                      <ArrowRight className="w-3 h-3 mt-0.5 shrink-0" style={{ color: '#D1D5DB' }} />
                      <span className="group-hover:underline leading-relaxed">{q}</span>
                    </Link>
                  ))}
                </div>
              </div>

              {/* Related Docs */}
              <div className="rounded-xl border p-5" style={{ border: '1px solid var(--stone-ridge)', background: '#FFFFFF' }}>
                <h4 className="text-xs font-semibold tracking-widest uppercase mb-4" style={{ color: '#94A3B8' }}>Related Docs</h4>
                <div className="space-y-2.5">
                  {['OpenROAD CTS Documentation', 'SDC Constraint Reference', 'Sky130 Clock Architecture'].map(d => (
                    <Link key={d} to="/docs" className="flex items-center gap-2 text-xs group" style={{ color: '#475569' }}>
                      <span className="w-4 h-4 flex items-center justify-center rounded text-white shrink-0" style={{ background: 'var(--abyss-ink)', fontSize: '0.5rem' }}>↗</span>
                      <span className="group-hover:underline">{d}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
